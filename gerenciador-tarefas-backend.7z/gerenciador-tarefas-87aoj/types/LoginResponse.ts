export type LoginResponse = {
    name : string,
    email : string,
    token : string
}