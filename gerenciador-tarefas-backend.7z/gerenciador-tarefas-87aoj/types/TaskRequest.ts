export type TaskRequest = {
    name : string,
    previsionDate : string,
    finishDate? : string
}