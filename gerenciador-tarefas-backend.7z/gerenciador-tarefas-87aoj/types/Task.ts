export type Task = {
    _id: string,
    name : string,
    previsionDate : string,
    finishDate? : string
}