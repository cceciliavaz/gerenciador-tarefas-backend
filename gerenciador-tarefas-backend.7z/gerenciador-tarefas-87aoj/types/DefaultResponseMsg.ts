export type DefaultResponseMsg = {
    msg? : string,
    error? : string
}