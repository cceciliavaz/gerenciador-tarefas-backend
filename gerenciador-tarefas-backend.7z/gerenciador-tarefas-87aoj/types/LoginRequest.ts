export type LoginRequest = {
    login : string,
    password : string
}