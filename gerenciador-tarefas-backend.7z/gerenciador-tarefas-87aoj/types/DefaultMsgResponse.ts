export type DefaultMsgResponse = {
    msg? : string,
    error? : string
}