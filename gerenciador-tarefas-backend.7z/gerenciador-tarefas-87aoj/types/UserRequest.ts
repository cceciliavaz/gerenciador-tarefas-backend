export type UserRequest = {
    name : string,
    email : string,
    password : string
}