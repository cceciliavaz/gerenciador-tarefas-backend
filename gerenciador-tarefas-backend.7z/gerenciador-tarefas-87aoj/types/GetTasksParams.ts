export type GetTasksParams = {
    previsionDateStart? : string,
    previsionDateEnd? : string,
    status? : string
}